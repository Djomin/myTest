﻿using System;

namespace Hello2
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Console.WriteLine ("Привет, Всем !+!+!");
		}
	}
}
